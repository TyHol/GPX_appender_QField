import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property string selectedFilePath: ""

    // Field names of the currently selected import layer (for mapping UI)
    property var layerFieldNames: []


    // GPX tags we know how to detect and map
    readonly property var knownGpxTags: [
        "ele","time","name","desc","cmt","sat","hdop","vdop","pdop",
        "sym","type","fix","speed","course","magvar"
    ]

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(gpxButton)
        iface.addItemToPluginsToolbar(exportButton)
    }

    // ── FeatureModel for import (batch mode) ─────────────────────────────────
    FeatureModel {
        id: importFeatureModel
        project: qgisProject
    }

    // ── FeatureModel for export (read individual features by ID) ─────────────
    FeatureModel {
        id: exportFeatureModel
        project: qgisProject
    }

    // ── Feature checklist for selective export ────────────────────────────────
    // items: { wkt: string, label: string, checked: bool }
    ListModel { id: exportFeaturesModel }

    // ── Field-mapping state (one row per detected GPX tag) ───────────────────
    ListModel {
        id: fieldMappingModel
        // items: { gpxTag: string, fieldIdx: int (-1 = ignore) }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  IMPORT toolbar button + dialog
    // ══════════════════════════════════════════════════════════════════════════

    QfToolButton {
        id: gpxButton
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: {
            refreshLayers()
            selectedFilePath = ""
            fileLabel.text = qsTr("No file selected")
            gpxTextArea.text = ""
            fieldMappingModel.clear()
            statusLabel.text = ""
            progressBar.visible = false
            gpxDialog.open()
        }
    }

    Dialog {
        id: gpxDialog
        parent: mainWindow.contentItem
        title: qsTr("GPX Appender v0.27 — Import")
        standardButtons: Dialog.Close
        closePolicy: Popup.CloseOnEscape

        onClosed: {
            importButton.enabled = Qt.binding(function() {
                return gpxTextArea.text.trim() !== "" && layerSelector.currentIndex >= 0
            })
            progressBar.indeterminate = false
            progressBar.visible = false
        }

        anchors.centerIn: parent
        width:  parent.width - 20
        height: Math.min(implicitHeight, parent.height - Theme.popupScreenEdgeMargin * 2)

        ScrollView {
            anchors.fill: parent
            contentWidth: availableWidth
            clip: true
            ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
            ScrollBar.vertical.policy:   ScrollBar.AsNeeded

        ColumnLayout {
            id: dialogLayout
            width: gpxDialog.availableWidth
            spacing: 12

            // ── Destination layer ─────────────────────────────────────────────
            Label { text: qsTr("Destination layer"); font: Theme.defaultFont; color: Theme.mainTextColor }
            ComboBox {
                id: layerSelector
                Layout.fillWidth: true
                model: []
                font: Theme.defaultFont
                onCurrentTextChanged: {
                    // Rebuild field mapping when layer changes
                    if (gpxTextArea.text.trim() !== "")
                        buildFieldMapping(gpxTextArea.text)
                }
            }

            // ── File picker ───────────────────────────────────────────────────
            Label { text: qsTr("GPX file"); font: Theme.defaultFont; color: Theme.mainTextColor }
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Button {
                    text: qsTr("Browse…")
                    font: Theme.defaultFont
                    onClicked: gpxFileDialog.open()
                }
                Label {
                    id: fileLabel
                    Layout.fillWidth: true
                    text: qsTr("No file selected")
                    font: Theme.tipFont
                    color: Theme.secondaryTextColor
                    elide: Text.ElideMiddle
                }
            }

            FileDialog {
                id: gpxFileDialog
                title: qsTr("Select a GPX file")
                nameFilters: ["GPX files (*.gpx)", "All files (*)"]
                onAccepted: {
                    var url  = gpxFileDialog.selectedFile.toString()
                    var path = url.replace(/^file:\/\/\/(?=[a-zA-Z]:)/, "").replace(/^file:\/\//, "")
                    fileLabel.text = FileUtils.fileName(path)
                    statusLabel.text = qsTr("Reading file…")
                    progressBar.indeterminate = true
                    progressBar.visible = true

                    var readPath = path
                    var tempPath = ""
                    if (!FileUtils.isWithinProjectDirectory(path)) {
                        var projDir = qgisProject.homePath
                        tempPath = projDir + "/_gpx_tmp_" + FileUtils.fileName(path)
                        if (!platformUtilities.renameFile(path, tempPath, true)) {
                            statusLabel.text = qsTr("Could not access file. Paste content below.")
                            progressBar.visible = false
                            return
                        }
                        readPath = tempPath
                    }
                    try {
                        var raw = FileUtils.readFileContent(readPath)
                        var text = ""
                        var asStr = String(raw)
                        if (asStr && asStr.trim().startsWith("<")) {
                            text = asStr
                        } else if (raw && raw.length > 0) {
                            for (var i = 0; i < raw.length; i++)
                                text += String.fromCharCode(raw[i])
                        }
                        if (text.trim().startsWith("<")) {
                            gpxTextArea.text = text
                            onGpxLoaded(text)
                        } else {
                            statusLabel.text = qsTr("File content looks wrong. Paste below.")
                        }
                    } catch (e) {
                        statusLabel.text = qsTr("Could not read file: ") + e
                    }
                    if (tempPath !== "")
                        platformUtilities.renameFile(tempPath, path, true)
                    progressBar.indeterminate = false
                    progressBar.value = 1
                    progressBar.visible = false
                }
            }

            // ── GPX content ───────────────────────────────────────────────────
            Label { text: qsTr("GPX content"); font: Theme.defaultFont; color: Theme.mainTextColor }
            Button {
                Layout.fillWidth: true
                text: qsTr("📋  Paste from clipboard")
                font: Theme.defaultFont
                onClicked: {
                    progressBar.indeterminate = true
                    progressBar.visible = true
                    gpxTextArea.selectAll()
                    gpxTextArea.paste()
                    Qt.callLater(function() {
                        progressBar.indeterminate = false
                        progressBar.visible = false
                        if (gpxTextArea.text.trim().length > 0)
                            onGpxLoaded(gpxTextArea.text)
                    })
                }
            }
            Label {
                Layout.fillWidth: true
                text: qsTr("Or browse/paste manually below:")
                font: Theme.tipFont; color: Theme.secondaryTextColor; wrapMode: Text.Wrap
            }
            ScrollView {
                id: gpxScrollView
                Layout.fillWidth: true
                Layout.preferredHeight: 160
                clip: true
                ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                ScrollBar.vertical.policy:   ScrollBar.AsNeeded
                TextArea {
                    id: gpxTextArea
                    width: gpxScrollView.width
                    placeholderText: qsTr("<?xml version=\"1.0\"?>\n<gpx …>\n  …\n</gpx>")
                    wrapMode: TextArea.Wrap
                    font.family: "monospace"
                    font.pointSize: Theme.tipFont.pointSize
                }
            }

            // ── Field mapping (shown once GPX is loaded) ──────────────────────
            Label {
                visible: fieldMappingModel.count > 0
                text: qsTr("Field mapping")
                font: Theme.defaultFont
                color: Theme.mainTextColor
            }
            Label {
                visible: fieldMappingModel.count > 0
                Layout.fillWidth: true
                text: qsTr("Map GPX tags → layer fields (or ignore):")
                font: Theme.tipFont; color: Theme.secondaryTextColor; wrapMode: Text.Wrap
            }
            Repeater {
                model: fieldMappingModel
                delegate: RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    property int rowIdx: index
                    Label {
                        text: gpxTag
                        font: Theme.defaultFont
                        color: Theme.mainTextColor
                        Layout.preferredWidth: 80
                    }
                    ComboBox {
                        Layout.fillWidth: true
                        font: Theme.defaultFont
                        model: [qsTr("(ignore)")].concat(layerFieldNames)
                        currentIndex: fieldIdx + 1
                        onCurrentIndexChanged: {
                            fieldMappingModel.setProperty(rowIdx, "fieldIdx", currentIndex - 1)
                        }
                    }
                }
            }

            // ── Import button ─────────────────────────────────────────────────
            Button {
                id: importButton
                Layout.fillWidth: true
                text: qsTr("Import")
                font: Theme.defaultFont
                enabled: gpxTextArea.text.trim() !== "" && layerSelector.currentIndex >= 0
                onClicked: startImport()
            }

            ProgressBar {
                id: progressBar
                Layout.fillWidth: true
                visible: false
                from: 0; to: 1; value: 0
                indeterminate: false
            }

            Label {
                id: statusLabel
                Layout.fillWidth: true
                wrapMode: Text.Wrap
                font: Theme.tipFont
                color: Theme.secondaryTextColor
                text: ""
            }
        }
        }   // end ScrollView
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  EXPORT toolbar button + dialog
    // ══════════════════════════════════════════════════════════════════════════

    QfToolButton {
        id: exportButton
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"   // TODO: separate export icon
        iconColor: "orange"
        round: true
        onClicked: {
            refreshLayersForExport()
            exportStatusLabel.text = ""
            exportPathLabel.text = qsTr("No location chosen")
            exportProgressBar.visible = false
            exportDialog.open()
        }
    }

    Dialog {
        id: exportDialog
        parent: mainWindow.contentItem
        title: qsTr("GPX Appender v0.27 — Export")
        standardButtons: Dialog.Close
        closePolicy: Popup.CloseOnEscape
        anchors.centerIn: parent
        width:  parent.width - 20
        height: Math.min(implicitHeight, parent.height - Theme.popupScreenEdgeMargin * 2)

        ColumnLayout {
            anchors.left: parent.left
            anchors.right: parent.right
            spacing: 12

            Label { text: qsTr("Layer to export"); font: Theme.defaultFont; color: Theme.mainTextColor }
            ComboBox {
                id: exportLayerSelector
                Layout.fillWidth: true
                model: []
                font: Theme.defaultFont
                onCurrentTextChanged: loadExportFeatures()
            }

            // ── Feature checklist ─────────────────────────────────────────────
            RowLayout {
                Layout.fillWidth: true
                Label {
                    id: exportFeaturesLabel
                    Layout.fillWidth: true
                    text: exportFeaturesModel.count > 0
                          ? qsTr("%1 feature(s) — tick to select for export:").arg(exportFeaturesModel.count)
                          : qsTr("No features loaded")
                    font: Theme.tipFont
                    color: Theme.secondaryTextColor
                    wrapMode: Text.Wrap
                }
                Button {
                    text: qsTr("All")
                    font: Theme.tipFont
                    visible: exportFeaturesModel.count > 0
                    onClicked: { for (var i = 0; i < exportFeaturesModel.count; i++) exportFeaturesModel.setProperty(i, "checked", true) }
                }
                Button {
                    text: qsTr("None")
                    font: Theme.tipFont
                    visible: exportFeaturesModel.count > 0
                    onClicked: { for (var i = 0; i < exportFeaturesModel.count; i++) exportFeaturesModel.setProperty(i, "checked", false) }
                }
            }
            ScrollView {
                Layout.fillWidth: true
                Layout.preferredHeight: Math.min(exportFeaturesModel.count * 44, 180)
                visible: exportFeaturesModel.count > 0
                clip: true
                ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                ScrollBar.vertical.policy: ScrollBar.AsNeeded
                ColumnLayout {
                    width: exportDialog.availableWidth
                    spacing: 0
                    Repeater {
                        model: exportFeaturesModel
                        delegate: CheckBox {
                            Layout.fillWidth: true
                            text: label
                            checked: model.checked
                            font: Theme.tipFont
                            onCheckedChanged: exportFeaturesModel.setProperty(index, "checked", checked)
                        }
                    }
                }
            }

            // Save location
            Label { text: qsTr("Save location"); font: Theme.defaultFont; color: Theme.mainTextColor }
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Button {
                    text: qsTr("Choose…")
                    font: Theme.defaultFont
                    onClicked: exportSaveDialog.open()
                }
                Label {
                    id: exportPathLabel
                    Layout.fillWidth: true
                    text: qsTr("No location chosen")
                    font: Theme.tipFont
                    color: Theme.secondaryTextColor
                    elide: Text.ElideMiddle
                    wrapMode: Text.Wrap
                }
            }

            FileDialog {
                id: exportSaveDialog
                title: qsTr("Save GPX as…")
                fileMode: FileDialog.SaveFile
                nameFilters: ["GPX files (*.gpx)", "All files (*)"]
                onAccepted: {
                    exportPathLabel.text = exportSaveDialog.selectedFile.toString()
                }
            }

            Button {
                id: exportButton2
                Layout.fillWidth: true
                text: qsTr("Export")
                font: Theme.defaultFont
                enabled: exportLayerSelector.currentIndex >= 0
                         && exportPathLabel.text !== qsTr("No location chosen")
                onClicked: startExport()
            }

            ProgressBar {
                id: exportProgressBar
                Layout.fillWidth: true
                visible: false
                from: 0; to: 1; value: 0
                indeterminate: false
            }

            Label {
                id: exportStatusLabel
                Layout.fillWidth: true
                wrapMode: Text.Wrap
                font: Theme.tipFont
                color: Theme.secondaryTextColor
                text: ""
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  IMPORT logic
    // ══════════════════════════════════════════════════════════════════════════

    function onGpxLoaded(xml) {
        var hasLines  = xml.indexOf("<trkseg") !== -1 || xml.indexOf("<trk>") !== -1
                     || xml.indexOf("<trk ")   !== -1 || xml.indexOf("<rte>") !== -1
        var hasPoints = xml.indexOf("<trkpt ") !== -1 || xml.indexOf("<wpt ") !== -1
                     || xml.indexOf("<wpt>")   !== -1 || xml.indexOf("<rtept ") !== -1
        refreshLayers()
        filterLayersByGpx(hasLines, hasPoints)
        buildFieldMapping(xml)
        statusLabel.text = summariseGpx(xml)
    }

    function filterLayersByGpx(hasLines, hasPoints) {
        if (!hasLines && !hasPoints) return
        var allNames = layerSelector.model
        if (!allNames || allNames.length === 0) return
        var filtered = []
        for (var i = 0; i < allNames.length; i++) {
            var arr = qgisProject.mapLayersByName(allNames[i])
            if (!arr || arr.length === 0) continue
            var gt = arr[0].geometryType ? arr[0].geometryType() : -1
            if (hasLines  && gt === Qgis.GeometryType.Line)  filtered.push(allNames[i])
            if (hasPoints && gt === Qgis.GeometryType.Point) filtered.push(allNames[i])
        }
        if (filtered.length > 0) {
            filtered.sort()
            layerSelector.model = filtered
            layerSelector.currentIndex = 0
        }
    }

    // Build the field mapping model from detected GPX tags + layer fields
    function buildFieldMapping(xml) {
        fieldMappingModel.clear()
        var layerName = layerSelector.currentText
        if (!layerName) return
        var layer = qgisProject.mapLayersByName(layerName)[0]
        if (!layer) return

        // Collect field names for this layer
        layerFieldNames = layer.fields.names

        for (var t = 0; t < knownGpxTags.length; t++) {
            var tag = knownGpxTags[t]
            // Only include tags actually present in this GPX file
            if (xml.indexOf("<" + tag + ">") === -1 && xml.indexOf("<" + tag + " ") === -1)
                continue
            var bestIdx = autoMatchField(tag, layerFieldNames)
            fieldMappingModel.append({ gpxTag: tag, fieldIdx: bestIdx })
        }
    }

    // Auto-match a GPX tag to the best layer field name
    function autoMatchField(tag, fieldNames) {
        var aliases = {
            "ele":    ["ele","elevation","elev","altitude","alt","height"],
            "time":   ["time","timestamp","datetime","date_time","date"],
            "name":   ["name","label"],
            "desc":   ["desc","description","notes"],
            "cmt":    ["cmt","comment","comments","note"],
            "sat":    ["sat","satellites","num_sat"],
            "hdop":   ["hdop"],
            "vdop":   ["vdop"],
            "pdop":   ["pdop"],
            "sym":    ["sym","symbol","icon"],
            "type":   ["type","feature_type","feat_type"],
            "fix":    ["fix","fix_type"],
            "speed":  ["speed"],
            "course": ["course","bearing","direction"],
            "magvar": ["magvar","magnetic_variation"]
        }
        var candidates = aliases[tag] || [tag]
        for (var c = 0; c < candidates.length; c++) {
            var idx = fieldNames.indexOf(candidates[c])
            if (idx !== -1) return idx
        }
        return -1  // ignore
    }

    function refreshLayers() {
        var layers = ProjectUtils.mapLayers(qgisProject)
        var names = []
        for (var id in layers) {
            var layer = layers[id]
            if (!layer || !layer.supportsEditing) continue
            var gt = layer.geometryType ? layer.geometryType() : -1
            if (gt === Qgis.GeometryType.Point || gt === Qgis.GeometryType.Line)
                names.push(layer.name)
        }
        names.sort()
        layerSelector.model = names
        layerSelector.currentIndex = names.length > 0 ? 0 : -1
    }

    function startImport() {
        var layerName = layerSelector.currentText
        if (!layerName) { statusLabel.text = qsTr("Please select a layer."); return }
        var layer = qgisProject.mapLayersByName(layerName)[0]
        if (!layer) { statusLabel.text = qsTr("Layer not found: ") + layerName; return }
        var xml = gpxTextArea.text.trim()
        if (!xml) { statusLabel.text = qsTr("Please paste GPX content first."); return }

        var gt = layer.geometryType ? layer.geometryType() : -1
        statusLabel.text = qsTr("Parsing GPX…")
        progressBar.indeterminate = true
        progressBar.visible = true
        importButton.enabled = false

        var count = (gt === Qgis.GeometryType.Line)
            ? importAsLines(layer, xml)
            : importAsPoints(layer, xml)

        progressBar.indeterminate = false
        progressBar.value = 1.0
        importButton.enabled = true
        statusLabel.text = count > 0
            ? qsTr("%1 feature(s) imported into '%2'.").arg(count).arg(layerName)
            : qsTr("No features found — check the GPX is valid.")
        if (count > 0)
            mainWindow.displayToast(qsTr("%1 feature(s) imported").arg(count))
    }

    function gpxPointToLayerCrs(p, layerCrs) {
        var wgs84 = CoordinateReferenceSystemUtils.wgs84Crs()
        var src = (p.ele !== null)
            ? GeometryUtils.point(p.lon, p.lat, p.ele)
            : GeometryUtils.point(p.lon, p.lat)
        return GeometryUtils.reprojectPoint(src, wgs84, layerCrs)
    }

    // Use field mapping model to stamp attributes onto a feature
    function stampMappedFields(feat, p) {
        for (var i = 0; i < fieldMappingModel.count; i++) {
            var item = fieldMappingModel.get(i)
            if (item.fieldIdx < 0) continue
            var val = p[item.gpxTag]
            if (val === undefined || val === null || val === "") continue
            feat.setAttribute(item.fieldIdx, val)
        }
    }

    function importAsPoints(layer, xml) {
        var pts = []
        pts = pts.concat(parsePointElements(xml, "wpt"))
        pts = pts.concat(parsePointElements(xml, "trkpt"))
        pts = pts.concat(parsePointElements(xml, "rtept"))
        if (pts.length === 0) return 0

        var layerCrs = layer.crs
        importFeatureModel.currentLayer = layer
        importFeatureModel.batchMode = true
        var count = 0
        for (var i = 0; i < pts.length; i++) {
            try {
                var p = pts[i]
                var lp = gpxPointToLayerCrs(p, layerCrs)
                if (!lp) continue
                var wkt = (p.ele !== null)
                    ? "POINT Z(" + lp.x + " " + lp.y + " " + lp.z + ")"
                    : "POINT("   + lp.x + " " + lp.y + ")"
                var geom = GeometryUtils.createGeometryFromWkt(wkt)
                if (!geom && p.ele !== null) {
                    wkt  = "POINT(" + lp.x + " " + lp.y + ")"
                    geom = GeometryUtils.createGeometryFromWkt(wkt)
                }
                if (!geom) continue
                var feat = FeatureUtils.createBlankFeature(layer.fields, geom)
                stampMappedFields(feat, p)
                importFeatureModel.feature = feat
                if (importFeatureModel.create()) count++
            } catch(e) {
                iface.logMessage("GPX import point error: " + e)
            }
        }
        importFeatureModel.batchMode = false
        return count
    }

    function importAsLines(layer, xml) {
        var layerCrs = layer.crs
        importFeatureModel.currentLayer = layer
        importFeatureModel.batchMode = true
        var count = 0
        var segs = splitByTag(xml, "trkseg")
        for (var i = 0; i < segs.length; i++) {
            var pts = parsePointElements(segs[i], "trkpt")
            if (pts.length < 2) continue
            var feat = buildLineFeature(layer, pts, "", layerCrs)
            if (feat) { importFeatureModel.feature = feat; if (importFeatureModel.create()) count++ }
        }
        var rtes = splitByTag(xml, "rte")
        for (var j = 0; j < rtes.length; j++) {
            var rpts = parsePointElements(rtes[j], "rtept")
            if (rpts.length < 2) continue
            var rf = buildLineFeature(layer, rpts, extractTagValue(rtes[j], "name") || "", layerCrs)
            if (rf) { importFeatureModel.feature = rf; if (importFeatureModel.create()) count++ }
        }
        importFeatureModel.batchMode = false
        return count
    }

    function buildLineFeature(layer, pts, name, layerCrs) {
        var hasZ = pts.some(function(p) { return p.ele !== null })
        var coords = pts.map(function(p) {
            var lp = gpxPointToLayerCrs(p, layerCrs)
            return hasZ ? (lp.x + " " + lp.y + " " + (p.ele !== null ? lp.z : 0))
                        : (lp.x + " " + lp.y)
        }).join(", ")
        var wkt = hasZ ? "LINESTRING Z(" + coords + ")" : "LINESTRING(" + coords + ")"
        var geom = GeometryUtils.createGeometryFromWkt(wkt)
        if (!geom) return null
        var feat = FeatureUtils.createBlankFeature(layer.fields, geom)
        if (name) trySetField(feat, layer.fields, ["name"], name)
        return feat
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  EXPORT logic
    // ══════════════════════════════════════════════════════════════════════════

    function refreshLayersForExport() {
        var layers = ProjectUtils.mapLayers(qgisProject)
        var names = []
        for (var id in layers) {
            var layer = layers[id]
            if (!layer) continue
            var gt = layer.geometryType ? layer.geometryType() : -1
            if (gt === Qgis.GeometryType.Point || gt === Qgis.GeometryType.Line)
                names.push(layer.name)
        }
        names.sort()
        exportLayerSelector.model = names
        exportLayerSelector.currentIndex = names.length > 0 ? 0 : -1
        // onCurrentTextChanged fires when model/index changes, but call explicitly
        // in case the selected layer name didn't change between opens
        loadExportFeatures()
    }

    // Load all layer features into the checklist model (called on layer change)
    function loadExportFeatures() {
        exportFeaturesModel.clear()
        var layerName = exportLayerSelector.currentText
        if (!layerName) return
        var layer = qgisProject.mapLayersByName(layerName)[0]
        if (!layer) return

        layer.selectAll()
        var features = null
        try { features = layer.selectedFeatures ? layer.selectedFeatures() : null } catch(e) {}
        layer.removeSelection()
        if (!features || features.length === 0) return

        // Name-candidate fields for display label
        var nameCandidates = ["name","label","desc","description","title","id","fid"]

        for (var i = 0; i < features.length; i++) {
            var f       = features[i]
            var label   = qsTr("Feature %1").arg(i + 1)
            var wkt     = ""

            // Try to get a human-readable label from attributes
            for (var nc = 0; nc < nameCandidates.length; nc++) {
                try {
                    var val = f.attribute(nameCandidates[nc])
                    if (val !== null && val !== undefined && String(val).trim() !== "") {
                        label = String(val).trim()
                        break
                    }
                } catch(e) {}
            }
            try { wkt = f.geometry.asWkt ? f.geometry.asWkt() : "" } catch(e) {}

            exportFeaturesModel.append({ wkt: wkt, label: label, checked: true })
        }
    }

    function startExport() {
        var layerName = exportLayerSelector.currentText
        if (!layerName) { exportStatusLabel.text = qsTr("Please select a layer."); return }
        var layer = qgisProject.mapLayersByName(layerName)[0]
        if (!layer) { exportStatusLabel.text = qsTr("Layer not found."); return }

        var destUrl  = exportSaveDialog.selectedFile.toString()
        var destPath = destUrl.replace(/^file:\/\/\/(?=[a-zA-Z]:)/, "").replace(/^file:\/\//, "")
        if (!destPath) { exportStatusLabel.text = qsTr("Please choose a save location."); return }

        exportProgressBar.indeterminate = true
        exportProgressBar.visible = true
        exportButton2.enabled = false
        exportStatusLabel.text = qsTr("Exporting…")

        var gt    = layer.geometryType ? layer.geometryType() : -1
        var wgs84 = CoordinateReferenceSystemUtils.wgs84Crs()
        var lCrs  = layer.crs

        doExport(layer, gt, lCrs, wgs84, destPath)
    }

    function doExport(layer, gt, lCrs, wgs84, destPath) {
        // ── Build WKT filter from checklist ───────────────────────────────────
        // exportFeaturesModel contains { wkt, label, checked } for every feature.
        // If everything is checked (or model is empty) → export all.
        // If any box is unchecked → export only checked WKTs.
        var checkedWkts = {}
        var anyUnchecked = false
        for (var mi = 0; mi < exportFeaturesModel.count; mi++) {
            var item = exportFeaturesModel.get(mi)
            if (item.checked) checkedWkts[item.wkt] = true
            else              anyUnchecked = true
        }
        var useFilter = anyUnchecked && Object.keys(checkedWkts).length > 0

        if (anyUnchecked && Object.keys(checkedWkts).length === 0) {
            exportStatusLabel.text = qsTr("No features ticked — tick at least one to export.")
            exportProgressBar.visible = false
            exportButton2.enabled = true
            return
        }

        // ── Get all features (only reliable path in QField QML) ───────────────
        layer.selectAll()
        var allFeatures = null
        try { allFeatures = layer.selectedFeatures ? layer.selectedFeatures() : null } catch(e) {}
        layer.removeSelection()

        if (!allFeatures || allFeatures.length === 0) {
            exportStatusLabel.text = qsTr("No features found in layer.")
            exportProgressBar.visible = false
            exportButton2.enabled = true
            return
        }

        // ── Filter to ticked features ─────────────────────────────────────────
        var featureList = []
        if (useFilter) {
            for (var fi = 0; fi < allFeatures.length; fi++) {
                var wktF = ""
                try { wktF = allFeatures[fi].geometry.asWkt ? allFeatures[fi].geometry.asWkt() : "" } catch(e) {}
                if (checkedWkts[wktF]) featureList.push(allFeatures[fi])
            }
        } else {
            featureList = allFeatures
        }

        // ── Build GPX ─────────────────────────────────────────────────────────
        var xml      = '<?xml version="1.0" encoding="UTF-8"?>\n'
        xml         += '<gpx version="1.1" creator="QField GPX Appender">\n'
        var exported = 0
        var skipped  = 0

        for (var i = 0; i < featureList.length; i++) {
            var feature = featureList[i]
            if (!feature) { skipped++; continue }

            if (gt === Qgis.GeometryType.Point) {
                try {
                    var pt  = GeometryUtils.centroid(feature.geometry)
                    var wPt = GeometryUtils.reprojectPoint(pt, lCrs, wgs84)
                    xml += '  <wpt lat="' + wPt.y + '" lon="' + wPt.x + '">\n'
                    if (!isNaN(wPt.z) && wPt.z !== 0) xml += '    <ele>' + wPt.z.toFixed(3) + '</ele>\n'
                    xml += buildAttributeTags(feature, layer.fields, "    ")
                    xml += '  </wpt>\n'
                    exported++
                } catch(e) { skipped++ }

            } else if (gt === Qgis.GeometryType.Line) {
                try {
                    xml += '  <trk>\n'
                    xml += buildAttributeTags(feature, layer.fields, "    ")
                    xml += '    <trkseg>\n'
                    var wktStr = ""
                    try { wktStr = feature.geometry.asWkt ? feature.geometry.asWkt() : "" } catch(e2) {}
                    var verts = parseWktVertices(wktStr, lCrs, wgs84)
                    for (var v = 0; v < verts.length; v++) {
                        xml += '      <trkpt lat="' + verts[v].lat + '" lon="' + verts[v].lon + '">'
                        if (verts[v].ele !== null) xml += '<ele>' + verts[v].ele.toFixed(3) + '</ele>'
                        xml += '</trkpt>\n'
                    }
                    xml += '    </trkseg>\n  </trk>\n'
                    exported++
                } catch(e) { skipped++ }
            }
        }
        xml += '</gpx>\n'

        if (exported === 0) {
            exportStatusLabel.text = qsTr("No features exported (skipped %1).").arg(skipped)
            exportProgressBar.visible = false
            exportButton2.enabled = true
            return
        }

        // Try writing directly to the chosen destination first.
        // This works for file:// paths and for content:// URIs on Android
        // (QField's FileUtils handles SAF on Android).
        // If that fails, write to a tmp file in the project folder and rename —
        // the rename may also fail across Android storage volumes, in which case
        // the file stays in the project folder and we tell the user where it is.
        var wrote = false
        try { wrote = FileUtils.writeFileContent(destPath, xml) } catch(e) {}

        if (wrote) {
            exportStatusLabel.text = qsTr("Exported %1 feature(s) to:\n%2").arg(exported).arg(destPath)
            mainWindow.displayToast(qsTr("GPX exported: %1 feature(s)").arg(exported))
        } else {
            var projDir = qgisProject.homePath
            var tmpPath = projDir + "/_gpx_export_tmp.gpx"
            if (FileUtils.writeFileContent(tmpPath, xml)) {
                if (platformUtilities.renameFile(tmpPath, destPath, true)) {
                    exportStatusLabel.text = qsTr("Exported %1 feature(s) to:\n%2").arg(exported).arg(destPath)
                    mainWindow.displayToast(qsTr("GPX exported: %1 feature(s)").arg(exported))
                } else {
                    // rename failed (common on Android cross-volume) — file is safe in project folder
                    exportStatusLabel.text = qsTr("Exported %1 feature(s).\nSaved in project folder:\n%2").arg(exported).arg(tmpPath)
                    mainWindow.displayToast(qsTr("GPX saved to project folder"))
                }
            } else {
                exportStatusLabel.text = qsTr("Could not write GPX file.")
            }
        }

        exportProgressBar.indeterminate = false
        exportProgressBar.value = 1
        exportButton2.enabled = true
    }

    // Build GPX child tags for well-known attribute fields
    function buildAttributeTags(feature, fields, indent) {
        var tagMap = [
            { fields: ["name","label"],                          tag: "name"  },
            { fields: ["desc","description","notes"],            tag: "desc"  },
            { fields: ["cmt","comment","comments"],              tag: "cmt"   },
            { fields: ["sym","symbol"],                          tag: "sym"   },
            { fields: ["type","feature_type"],                   tag: "type"  },
        ]
        var out = ""
        for (var i = 0; i < tagMap.length; i++) {
            var val = findFieldValue(feature, fields, tagMap[i].fields)
            if (val !== null && val !== "") out += indent + "<" + tagMap[i].tag + ">" + val + "</" + tagMap[i].tag + ">\n"
        }
        return out
    }

    function findFieldValue(feature, fields, candidates) {
        for (var i = 0; i < candidates.length; i++) {
            var idx = fields.indexOf(candidates[i])
            if (idx !== -1) {
                var val = feature.attribute(candidates[i])
                if (val !== null && val !== undefined && val !== "") return String(val)
            }
        }
        return null
    }

    // Parse WKT vertices and reproject to WGS84
    // Handles LINESTRING (x y), LINESTRINGZ (x y z), etc.
    function parseWktVertices(wkt, srcCrs, dstCrs) {
        if (!wkt) return []
        // Strip type prefix, keep everything inside the outer parentheses
        var inner = wkt.replace(/^[^(]+\(/, "").replace(/\)$/, "").trim()
        // Strip inner parens (for MULTILINESTRING etc.) - take first ring
        if (inner.charAt(0) === "(") inner = inner.substring(1, inner.indexOf(")"))
        var verts = []
        var parts = inner.split(",")
        for (var i = 0; i < parts.length; i++) {
            var coords = parts[i].trim().split(/\s+/)
            if (coords.length < 2) continue
            var x = parseFloat(coords[0])
            var y = parseFloat(coords[1])
            var z = coords.length >= 3 ? parseFloat(coords[2]) : null
            var srcPt = (z !== null) ? GeometryUtils.point(x, y, z) : GeometryUtils.point(x, y)
            var dstPt = GeometryUtils.reprojectPoint(srcPt, srcCrs, dstCrs)
            verts.push({ lat: dstPt.y, lon: dstPt.x, ele: (z !== null) ? dstPt.z : null })
        }
        return verts
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  GPX PARSING helpers
    // ══════════════════════════════════════════════════════════════════════════

    function parsePointElements(xml, tagName) {
        var results = [], pos = 0
        var openTag = "<" + tagName, closeTag = "</" + tagName + ">"
        while (true) {
            var tagStart = xml.indexOf(openTag, pos)
            if (tagStart === -1) break
            var tagEnd = xml.indexOf(">", tagStart)
            if (tagEnd === -1) break
            var header = xml.substring(tagStart, tagEnd + 1)
            var latM = header.match(/lat="([^"]+)"/)
            var lonM = header.match(/lon="([^"]+)"/)
            if (!latM || !lonM) { pos = tagEnd + 1; continue }
            var closePos = xml.indexOf(closeTag, tagEnd)
            var inner = ""
            if (closePos !== -1) { inner = xml.substring(tagEnd + 1, closePos); pos = closePos + closeTag.length }
            else { pos = tagEnd + 1 }
            var eleStr = extractTagValue(inner, "ele")
            results.push({
                lat:    parseFloat(latM[1]),
                lon:    parseFloat(lonM[1]),
                ele:    eleStr !== null ? parseFloat(eleStr) : null,
                time:   extractTagValue(inner, "time")   || "",
                name:   extractTagValue(inner, "name")   || "",
                desc:   extractTagValue(inner, "desc")   || "",
                cmt:    extractTagValue(inner, "cmt")    || "",
                sat:    extractTagValue(inner, "sat")    || "",
                hdop:   extractTagValue(inner, "hdop")   || "",
                vdop:   extractTagValue(inner, "vdop")   || "",
                pdop:   extractTagValue(inner, "pdop")   || "",
                sym:    extractTagValue(inner, "sym")    || "",
                type:   extractTagValue(inner, "type")   || "",
                fix:    extractTagValue(inner, "fix")    || "",
                speed:  extractTagValue(inner, "speed")  || "",
                course: extractTagValue(inner, "course") || "",
                magvar: extractTagValue(inner, "magvar") || ""
            })
        }
        return results
    }

    function splitByTag(xml, tagName) {
        var results = [], pos = 0
        var open = "<" + tagName + ">", close = "</" + tagName + ">"
        while (true) {
            var s = xml.indexOf(open, pos); if (s === -1) break
            var e = xml.indexOf(close, s);  if (e === -1) break
            results.push(xml.substring(s + open.length, e))
            pos = e + close.length
        }
        return results
    }

    function extractTagValue(xml, tag) {
        var s = xml.indexOf("<" + tag); if (s === -1) return null
        var e = xml.indexOf(">", s);   if (e === -1) return null
        if (xml[e - 1] === "/") return null
        var c = xml.indexOf("</" + tag + ">", e); if (c === -1) return null
        return xml.substring(e + 1, c).trim()
    }

    function trySetField(feat, fields, candidates, value) {
        if (value === undefined || value === null || value === "") return
        for (var i = 0; i < candidates.length; i++) {
            var idx = fields.indexOf(candidates[i])
            if (idx !== -1) { feat.setAttribute(idx, value); return }
        }
    }

    // ── GPX summary for status label ─────────────────────────────────────────
    function summariseGpx(xml) {
        var lines = []
        var wpts = countTag(xml, "wpt")
        if (wpts > 0) lines.push(wpts + " " + (wpts === 1 ? qsTr("waypoint") : qsTr("waypoints")))
        var trks = countTag(xml, "trk"), segs = countTag(xml, "trkseg"), trkpts = countTag(xml, "trkpt")
        if (trks > 0 || segs > 0) {
            var s = trks + " " + (trks === 1 ? qsTr("track") : qsTr("tracks"))
            if (segs > 0)   s += " (" + segs + " " + (segs === 1 ? qsTr("segment") : qsTr("segments")) + ")"
            if (trkpts > 0) s += " · " + trkpts + " " + qsTr("track points")
            lines.push(s)
        }
        var rtes = countTag(xml, "rte"), rtepts = countTag(xml, "rtept")
        if (rtes > 0) {
            var r = rtes + " " + (rtes === 1 ? qsTr("route") : qsTr("routes"))
            if (rtepts > 0) r += " · " + rtepts + " " + qsTr("route points")
            lines.push(r)
        }
        if (lines.length === 0) return qsTr("No tracks, routes or waypoints found.")
        return qsTr("Found: ") + lines.join("  |  ") + "\n" + qsTr("Press Import when ready.")
    }

    function countTag(xml, tagName) {
        var count = 0, search = "<" + tagName, pos = 0
        while (true) {
            var idx = xml.indexOf(search, pos)
            if (idx === -1) break
            var nc = xml.charAt(idx + search.length)
            if (nc === ">" || nc === " " || nc === "\t" || nc === "\n" || nc === "\r" || nc === "/") count++
            pos = idx + 1
        }
        return count
    }
}
